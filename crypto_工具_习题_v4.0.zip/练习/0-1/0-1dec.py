#!/usr/bin/python2.7
import binascii
import base64

data = open("0-1.txt").read()
dataArr = data.split()
binaryBuffer = ""

for w in dataArr:
  if "ZERO" in w:
    binaryBuffer += "0"
  if "ONE" in w:
    binaryBuffer += "1"

print binaryBuffer
n = int(binaryBuffer, 2)
k= int(binaryBuffer,8)
print n

binDecoded = binascii.unhexlify('%x' % n)
print binDecoded

base64Decoded = base64.b64decode(binDecoded)

print base64Decoded

CODE = {'.-': 'A',    '-...': 'B',  '-.-.': 'C',
        '-..': 'D',   '.': 'E',     '..-.': 'F',
        '--.': 'G',   '....': 'H',  '..': 'I',
        '.---': 'J',  '-.-': 'K',   '.-..': 'L',
        '--': 'M',    '-.': 'N',    '---': 'O',
        '.--.': 'P',  '--.-': 'Q',  '.-.': 'R',
        '...': 'S',   '-': 'T',     '..-': 'U',
        '...-': 'V',  '.--': 'W',   '-..-': 'X',
        '-.--': 'Y',  '--..': 'Z',

        '-----': '0', '.----': '1', '..---': '2',
        '...--': '3', '....-': '4', '.....': '5',
        '-....': '6', '--...': '7', '---..': '8',
        '----.': '9'
        }

morseDecoded = ''.join(CODE.get(i) for i in base64Decoded.split())

print morseDecoded
morseList = list(morseDecoded.lower())

alexCTF = ''.join(morseList[0:7])
flag = ""

for l in morseList[7:]:
    if "o" in l:
        flag += "_"
    else:
        flag += l

print "The flag is: " + alexCTF + "{" + flag + "}"
